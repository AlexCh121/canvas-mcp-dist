# QOrigin Canvas MCP 0.1.3 (release candidate)

This package runs a local bridge for the Canvas browser tab and a stdio MCP server for Codex. It does not run a second AI agent or hold a cloud login token.

## Local setup

```bash
cd canvas-agent
bun install --frozen-lockfile
bun run build
export QORIGIN_CANVAS_ORIGINS="https://your-canvas-origin.example"
node dist/index.js serve
```

Replace the example Origin with the exact Canvas Origin before starting the Bridge. The Bridge listens on `127.0.0.1:38621` and prints a one-use pairing code. In Canvas, open the assistant panel, select **Codex**, and enter the code. To create another code after a disconnect, run `node dist/index.js pair` while the bridge remains running.

Register this local build with Codex (replace the path with the absolute path on the customer's machine):

```bash
codex mcp add qorigin-canvas -- node /absolute/path/to/canvas-agent/dist/index.js mcp
codex mcp list
```

In Codex, call `canvas_list_connections`, then `canvas_select_connection` with the connection ID displayed in Canvas. Call `canvas_prepare_operation` before each write and pass the returned `operationId` unchanged to the write tool. If a write times out, call `canvas_get_operation_status` with that ID before deciding what to do next.

The web build must set `NEXT_PUBLIC_CANVAS_CUSTOMER_MCP_ENABLED=true`; the default is off. The Bridge refuses to start unless `QORIGIN_CANVAS_ORIGINS` names the exact authorized Canvas Origin. `QORIGIN_CANVAS_MCP_PORT` changes the loopback port, and `QORIGIN_CANVAS_MCP_HOME` changes the local configuration directory.

This package is not published to npm. Both the browser tab and Codex must run on the same computer as the bridge. Remote Codex executors and containers need another connection design. Customer rollout remains gated on the integrated production deployment and end-to-end validation.
